# Chapter 2 image asset attribution

* taco salad" by anneheathen is licensed with CC BY 2.0. To view a copy of this license, visit https://creativecommons.org/licenses/by/2.0/
* "Athena Pizza - Hawaiian Pizza" by elsie.hui is licensed with CC BY 2.0. To view a copy of this license, visit https://creativecommons.org/licenses/by/2.0/
* "Joe's of Westlake - Dinner" by BrownGuacamole is licensed under CC BY-ND 2.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nd/2.0/
* "Roasted Tomato Paleo Soup" by paleogrubs is licensed under CC BY 2.0. To view a copy of this license, visit https://creativecommons.org/licenses/by/2.0/
* "IMG_0562" by joelogon is licensed under CC BY-SA 2.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-sa/2.0/
* "Chocolate chip cookies" by Helena Jacoba is licensed under CC BY 2.0. To view a copy of this license, visit https://creativecommons.org/licenses/by/2.0/

